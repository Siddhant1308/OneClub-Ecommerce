import React from 'react'

const MyProfile = () => {
  return (
    <div>
      <h1>My Profile</h1>
    </div>
  )
}

export default MyProfile;